"""
🚀 그룹 2: 이미지 처리 및 데이터 저장 함수들
- 이미지 다운로드, 리사이즈, 저장 시스템
- CSV 데이터 저장 및 관리
- 파일 시스템 관리 및 최적화
"""

import os
import time
import random
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# config 모듈에서 모든 설정과 라이브러리 상태 import
from .config import CONFIG, get_city_info, get_city_code, PANDAS_AVAILABLE, PIL_AVAILABLE

# 조건부 import - config에서 확인된 상태에 따라
if PANDAS_AVAILABLE:
    import pandas as pd

# requests는 이 모듈에서만 필요하므로 로컬 체크
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    print("⚠️ requests가 설치되지 않았습니다. 이미지 다운로드 기능이 제한됩니다.")
    REQUESTS_AVAILABLE = False

if PIL_AVAILABLE:
    from PIL import Image

# =============================================================================
# 📸 이미지 처리 시스템
# =============================================================================

def get_image_src_klook(driver, url_type="Product"):
    """✅ 이미지 URL 수집 (KLOOK 최적화)"""
    print(f"  📸 {url_type} 이미지 수집 중...")

    image_selectors = [
        ("css", ".ActivityCardImage--image"),           # KLOOK 최우선 (100% 확인됨)
        ("css", ".card-pic img"),                       # KLOOK 백업
        ("css", ".activity-card-image img"),            # KLOOK 백업2  
        ("css", "img[alt*='activity']"),                # KLOOK 백업3
        ("css", "img[src*='klook']"),                   # KLOOK 도메인 이미지
        ("css", "img"),                                 # 범용 백업
    ]

    for selector_type, selector_value in image_selectors:
        try:
            if selector_type == "css":
                image_elements = driver.find_elements("css selector", selector_value)
            
            for img_element in image_elements:
                try:
                    img_src = img_element.get_attribute("src")
                    if img_src and ("klook" in img_src.lower() or "activity" in img_src.lower() or len(img_src) > 50):
                        return img_src
                except:
                    continue
                    
        except Exception:
            continue
    
    raise Exception("이미지를 찾을 수 없습니다")

def get_dual_image_urls_klook(driver, url_type="Product"):
    """✅ 메인 + 썸네일 이미지 URL 수집 (KLOOK 최적화)"""
    print(f"  📸 {url_type} 듀얼 이미지 수집 중...")
    
    # 메인 이미지와 썸네일 이미지 선택자들
    main_selectors = [
        ("css", ".ActivityCardImage--image"),           # KLOOK 메인 이미지
        ("css", ".product-hero-image img"),             # 상세 페이지 메인
        ("css", ".hero-image img"),                     # 히어로 이미지
        ("css", ".main-image img"),                     # 메인 이미지
    ]
    
    thumb_selectors = [
        ("css", ".thumbnail-image img"),                # 썸네일
        ("css", ".thumb img"),                          # 썸네일 백업
        ("css", ".gallery-thumb img"),                  # 갤러리 썸네일
        ("css", ".product-thumb img"),                  # 상품 썸네일
    ]
    
    images = {"main": None, "thumb": None}
    
    # 메인 이미지 찾기
    for selector_type, selector_value in main_selectors:
        try:
            if selector_type == "css":
                image_elements = driver.find_elements("css selector", selector_value)
            
            for img_element in image_elements:
                try:
                    img_src = img_element.get_attribute("src")
                    if img_src and ("klook" in img_src.lower() or "activity" in img_src.lower() or len(img_src) > 50):
                        images["main"] = img_src
                        break
                except:
                    continue
            
            if images["main"]:
                break
                    
        except Exception:
            continue
    
    # 썸네일 이미지 찾기 (선택사항)
    for selector_type, selector_value in thumb_selectors:
        try:
            if selector_type == "css":
                image_elements = driver.find_elements("css selector", selector_value)
            
            for img_element in image_elements:
                try:
                    img_src = img_element.get_attribute("src")
                    if img_src and img_src != images["main"] and ("klook" in img_src.lower() or "thumb" in img_src.lower() or len(img_src) > 30):
                        images["thumb"] = img_src
                        break
                except:
                    continue
            
            if images["thumb"]:
                break
                    
        except Exception:
            continue
    
    return images

def download_and_save_image_klook(img_src, product_number, city_name, max_size_kb=300):
    """✅ 이미지 다운로드 및 저장 (KLOOK 최적화)"""
    if not CONFIG["SAVE_IMAGES"]:
        return None
    
    if not REQUESTS_AVAILABLE:
        print("  ⚠️ requests가 설치되지 않아 이미지 다운로드를 건너뜁니다.")
        return None
    
    if not PIL_AVAILABLE:
        print("  ⚠️ PIL이 설치되지 않아 이미지 처리를 건너뜁니다.")
        return None
        
    print(f"  📥 이미지 다운로드 및 리사이즈 시작...")
    
    try:
        # 파일명 생성 (기존 시스템과 호환)
        city_code = get_city_code(city_name)
        img_filename = f"{city_code}_{product_number:04d}.jpg"  # BCN_0001.jpg 형식
        
        # 이미지 폴더 경로 (계층적 구조)
        continent, country = get_city_info(city_name)
        img_base_folder = os.path.join(os.getcwd(), "klook_thumb_img")
        
        # 기존 시스템과 호환되는 폴더 구조
        if city_name in ["마카오", "홍콩", "싱가포르"]:
            img_folder = os.path.join(img_base_folder, continent)
        else:
            img_folder = os.path.join(img_base_folder, continent, country, city_name)
        
        os.makedirs(img_folder, exist_ok=True)
        img_path = os.path.join(img_folder, img_filename)
        
        # 이미지 다운로드
        headers = {
            'User-Agent': CONFIG["USER_AGENT"],
            'Referer': 'https://www.klook.com/',
            'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8'
        }
        
        response = requests.get(img_src, headers=headers, timeout=10)
        response.raise_for_status()
        
        # 임시 파일에 저장
        temp_path = img_path + ".temp"
        with open(temp_path, 'wb') as f:
            f.write(response.content)
        
        # 이미지 리사이즈 및 최적화
        with Image.open(temp_path) as img:
            # RGB로 변환 (JPEG 호환성)
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            
            # 적절한 크기로 리사이즈 (가로 400px 기준)
            width, height = img.size
            if width > 400:
                ratio = 400 / width
                new_height = int(height * ratio)
                img = img.resize((400, new_height), Image.Resampling.LANCZOS)
            
            # 품질 조정하여 저장 (300KB 이하 목표)
            quality = 85
            while quality > 30:
                img.save(img_path, "JPEG", quality=quality, optimize=True)
                
                # 파일 크기 확인
                if os.path.getsize(img_path) <= max_size_kb * 1024:
                    break
                quality -= 10
        
        # 임시 파일 삭제
        if os.path.exists(temp_path):
            os.remove(temp_path)
        
        file_size_kb = os.path.getsize(img_path) / 1024
        print(f"  ✅ 이미지 저장 완료: {img_filename} ({file_size_kb:.1f}KB)")
        return img_filename
        
    except Exception as e:
        print(f"  ❌ 이미지 저장 실패: {type(e).__name__}: {e}")
        # 임시 파일 정리
        if 'temp_path' in locals() and os.path.exists(temp_path):
            os.remove(temp_path)
        return None

def download_dual_images_klook(image_urls, product_number, city_name, max_size_kb=300):
    """✅ 듀얼 이미지 다운로드 및 저장 (메인 + 썸네일, 메인만 fallback)"""
    if not CONFIG["SAVE_IMAGES"]:
        return {"main": None, "thumb": None}
    
    if not REQUESTS_AVAILABLE or not PIL_AVAILABLE:
        print("  ⚠️ 필요한 라이브러리가 설치되지 않아 이미지 다운로드를 건너뜁니다.")
        return {"main": None, "thumb": None}
    
    results = {"main": None, "thumb": None}
    
    # 메인 이미지 다운로드
    if image_urls.get("main"):
        print(f"  📥 메인 이미지 다운로드 중...")
        main_filename = download_single_image_klook(
            image_urls["main"], 
            product_number, 
            city_name, 
            image_type="main",
            max_size_kb=max_size_kb
        )
        results["main"] = main_filename
    
    # 썸네일 이미지 다운로드 (선택사항)
    if image_urls.get("thumb"):
        print(f"  📥 썸네일 이미지 다운로드 중...")
        thumb_filename = download_single_image_klook(
            image_urls["thumb"], 
            product_number, 
            city_name, 
            image_type="thumb",
            max_size_kb=max_size_kb//2  # 썸네일은 더 작게
        )
        results["thumb"] = thumb_filename
    
    # 결과 로그
    if results["main"] and results["thumb"]:
        print(f"  ✅ 듀얼 이미지 저장 완료: 메인 + 썸네일")
    elif results["main"]:
        print(f"  ✅ 메인 이미지만 저장 완료 (썸네일 없음)")
    else:
        print(f"  ❌ 이미지 저장 실패")
    
    return results

def download_single_image_klook(img_src, product_number, city_name, image_type="main", max_size_kb=300):
    """✅ 단일 이미지 다운로드 (메인/썸네일 구분)"""
    try:
        # 파일명 생성 (기존 시스템과 호환)
        city_code = get_city_code(city_name)
        if image_type == "main":
            img_filename = f"{city_code}_{product_number:04d}.jpg"  # BCN_0001.jpg
        else:
            img_filename = f"{city_code}_{product_number:04d}_{image_type}.jpg"  # BCN_0001_thumb.jpg
        
        # 이미지 폴더 경로 (계층적 구조)
        continent, country = get_city_info(city_name)
        img_base_folder = os.path.join(os.getcwd(), "klook_thumb_img")
        
        # 기존 시스템과 호환되는 폴더 구조
        if city_name in ["마카오", "홍콩", "싱가포르"]:
            img_folder = os.path.join(img_base_folder, continent)
        else:
            img_folder = os.path.join(img_base_folder, continent, country, city_name)
        
        os.makedirs(img_folder, exist_ok=True)
        img_path = os.path.join(img_folder, img_filename)
        
        # 이미지 다운로드
        headers = {
            'User-Agent': CONFIG["USER_AGENT"],
            'Referer': 'https://www.klook.com/',
            'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8'
        }
        
        response = requests.get(img_src, headers=headers, timeout=10)
        response.raise_for_status()
        
        # 임시 파일에 저장
        temp_path = img_path + ".temp"
        with open(temp_path, 'wb') as f:
            f.write(response.content)
        
        # 이미지 리사이즈 및 최적화
        with Image.open(temp_path) as img:
            # RGB로 변환 (JPEG 호환성)
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            
            # 타입별 크기 조정
            width, height = img.size
            if image_type == "main":
                target_width = 400  # 메인 이미지
            else:
                target_width = 200  # 썸네일 이미지
            
            if width > target_width:
                ratio = target_width / width
                new_height = int(height * ratio)
                img = img.resize((target_width, new_height), Image.Resampling.LANCZOS)
            
            # 품질 조정하여 저장
            quality = 85
            while quality > 30:
                img.save(img_path, "JPEG", quality=quality, optimize=True)
                
                # 파일 크기 확인
                if os.path.getsize(img_path) <= max_size_kb * 1024:
                    break
                quality -= 10
        
        # 임시 파일 삭제
        if os.path.exists(temp_path):
            os.remove(temp_path)
        
        file_size_kb = os.path.getsize(img_path) / 1024
        print(f"    ✅ {image_type} 이미지 저장: {img_filename} ({file_size_kb:.1f}KB)")
        return img_filename
        
    except Exception as e:
        print(f"    ❌ {image_type} 이미지 저장 실패: {type(e).__name__}: {e}")
        # 임시 파일 정리
        if 'temp_path' in locals() and os.path.exists(temp_path):
            os.remove(temp_path)
        return None

# =============================================================================
# 💾 CSV 데이터 저장 시스템
# =============================================================================

def save_to_csv_klook(product_data, city_name):
    """✅ CSV 저장 (KLOOK 최적화 + 도시국가 특별 처리)"""
    if not product_data:
        print("  ⚠️ 저장할 데이터가 없습니다.")
        return False
    
    if not PANDAS_AVAILABLE:
        print("  ⚠️ pandas가 설치되지 않아 CSV 저장을 건너뜁니다.")
        return False

    try:
        continent, country = get_city_info(city_name)
        
        # 도시국가 특별 처리 (기존 구조 호환)
        if city_name in ["마카오", "홍콩", "싱가포르"]:
            csv_dir = os.path.join("data", continent)
            csv_filename = f"{city_name}_klook_products_all.csv"  # 기존 파일명 형식
        else:
            csv_dir = os.path.join("data", continent, country, city_name)
            csv_filename = f"{city_name}_klook_products_all.csv"  # 기존 파일명 형식
        
        # 디렉토리 생성
        os.makedirs(csv_dir, exist_ok=True)
        csv_path = os.path.join(csv_dir, csv_filename)
        
        # DataFrame 생성
        df_new = pd.DataFrame([product_data])
        
        # 기존 파일이 있으면 추가, 없으면 새로 생성
        if os.path.exists(csv_path):
            df_existing = pd.read_csv(csv_path, encoding='utf-8-sig')
            df_combined = pd.concat([df_existing, df_new], ignore_index=True)
        else:
            df_combined = df_new
        
        # CSV로 저장
        df_combined.to_csv(csv_path, index=False, encoding='utf-8-sig')
        print(f"  💾 CSV 저장 완료: {csv_path}")
        print(f"     📊 총 상품 수: {len(df_combined)}개")
        
        return True
        
    except Exception as e:
        print(f"  ❌ CSV 저장 실패: {type(e).__name__}: {e}")
        return False

def create_product_data_structure(product_number, product_name, price, image_filename, url, city_name, additional_data=None, tab_info=None, dual_images=None):
    """✅ 상품 데이터 구조 생성 (기존 32개 컬럼 구조 적용)"""
    continent, country = get_city_info(city_name)
    city_code = get_city_code(city_name)
    
    # 기존 32개 컬럼 구조에 맞는 데이터 생성
    base_data = {
        # 기본 정보
        "번호": product_number,
        "도시ID": f"{city_code}_{product_number}",
        "페이지": tab_info.get("page", 1) if tab_info else 1,
        "대륙": continent,
        "국가": country,
        "도시": city_name,
        "공항코드": city_code,
        "상품타입": "Activity",
        "상품명": product_name,
        
        # 가격 정보
        "가격_원본": additional_data.get("가격_원본", price) if additional_data else price,
        "가격_정제": price,
        
        # 평점 및 리뷰
        "평점_원본": additional_data.get("평점_원본", "정보 없음") if additional_data else "정보 없음",
        "평점_정제": additional_data.get("평점", "정보 없음") if additional_data else "정보 없음",
        "리뷰수": additional_data.get("리뷰수", "정보 없음") if additional_data else "정보 없음",
        
        # 기타 정보
        "언어": additional_data.get("언어", "정보 없음") if additional_data else "정보 없음",
        "카테고리": additional_data.get("카테고리", "정보 없음") if additional_data else "정보 없음",
        "하이라이트": additional_data.get("하이라이트", "정보 없음") if additional_data else "정보 없음",
        "위치": additional_data.get("위치", "정보 없음") if additional_data else "정보 없음",
        
        # 메인 이미지 정보 (듀얼 이미지 시스템 적용)
        "메인이미지_파일명": dual_images.get("main") if dual_images and dual_images.get("main") else (image_filename if image_filename else "정보 없음"),
        "메인이미지_상대경로": f"{continent}\\{country}\\{city_name}\\{dual_images.get('main')}" if dual_images and dual_images.get("main") else (f"{continent}\\{country}\\{city_name}\\{image_filename}" if image_filename else "정보 없음"),
        "메인이미지_전체경로": f"klook_thumb_img\\{continent}\\{country}\\{city_name}\\{dual_images.get('main')}" if dual_images and dual_images.get("main") else (f"klook_thumb_img\\{continent}\\{country}\\{city_name}\\{image_filename}" if image_filename else "정보 없음"),
        "메인이미지_상태": "메인 다운로드 완료" if (dual_images and dual_images.get("main")) or image_filename else "다운로드 실패",
        
        # 썸네일 이미지 정보 (듀얼 이미지 시스템)
        "썸네일이미지_파일명": dual_images.get("thumb") if dual_images and dual_images.get("thumb") else "정보 없음",
        "썸네일이미지_상대경로": f"{continent}\\{country}\\{city_name}\\{dual_images.get('thumb')}" if dual_images and dual_images.get("thumb") else "정보 없음",
        "썸네일이미지_전체경로": f"klook_thumb_img\\{continent}\\{country}\\{city_name}\\{dual_images.get('thumb')}" if dual_images and dual_images.get("thumb") else "정보 없음",
        "썸네일이미지_상태": "썸네일 다운로드 완료" if dual_images and dual_images.get("thumb") else "정보 없음",
        
        # URL 및 메타데이터
        "URL": url,
        "수집_시간": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "상태": "완전수집",
        
        # 탭 및 랭킹 정보
        "탭명": tab_info.get("tab_name", "전체") if tab_info else "전체",
        "탭순서": tab_info.get("tab_order", 1) if tab_info else 1,
        "탭내_랭킹": tab_info.get("ranking", product_number) if tab_info else product_number,
        "URL_해시": additional_data.get("URL_해시", "") if additional_data else ""
    }
    
    # 추가 데이터가 있으면 기존 32개 컬럼 내에서만 업데이트 (추가 컬럼 생성 방지)
    if additional_data:
        print(f"    📝 추가 데이터 확인: {list(additional_data.keys())}")
        allowed_updates = ["가격_원본", "평점_원본", "평점", "리뷰수", "언어", "카테고리", "하이라이트", "위치", "URL_해시"]
        for key, value in additional_data.items():
            if key in allowed_updates and key in base_data:
                base_data[key] = value
                print(f"      ✅ 업데이트: {key} = {value}")
            elif key not in allowed_updates:
                print(f"      ⏭️ 스킵됨: {key} (32컬럼 구조 유지)")
    else:
        print(f"    ⚠️ 추가 데이터 없음 - additional_data가 비어있거나 None")
    
    return base_data

# =============================================================================
# 📊 데이터 관리 및 통계
# =============================================================================

def get_csv_stats(city_name):
    """CSV 파일 통계 정보 조회"""
    if not PANDAS_AVAILABLE:
        print("⚠️ pandas가 설치되지 않아 CSV 통계를 확인할 수 없습니다.")
        return {"exists": False, "error": "pandas not available"}
    
    try:
        continent, country = get_city_info(city_name)
        
        # 도시국가 특별 처리
        if city_name in ["마카오", "홍콩", "싱가포르"]:
            csv_path = os.path.join("data", continent, f"klook_{city_name}_products.csv")
        else:
            csv_path = os.path.join("data", continent, country, city_name, f"klook_{city_name}_products.csv")
        
        if not os.path.exists(csv_path):
            return {"exists": False, "count": 0, "last_updated": None}
        
        df = pd.read_csv(csv_path, encoding='utf-8-sig')
        file_mtime = os.path.getmtime(csv_path)
        last_updated = datetime.fromtimestamp(file_mtime).strftime("%Y-%m-%d %H:%M:%S")
        
        return {
            "exists": True,
            "count": len(df),
            "last_updated": last_updated,
            "file_size": os.path.getsize(csv_path),
            "columns": list(df.columns)
        }
        
    except Exception as e:
        print(f"⚠️ CSV 통계 조회 실패: {e}")
        return {"exists": False, "error": str(e)}

def backup_csv_data(city_name, backup_suffix=None):
    """CSV 데이터 백업"""
    try:
        continent, country = get_city_info(city_name)
        
        # 도시국가 특별 처리 (기존 구조 호환)
        if city_name in ["마카오", "홍콩", "싱가포르"]:
            csv_dir = os.path.join("data", continent)
            csv_filename = f"{city_name}_klook_products_all.csv"  # 기존 파일명 형식
        else:
            csv_dir = os.path.join("data", continent, country, city_name)
            csv_filename = f"{city_name}_klook_products_all.csv"  # 기존 파일명 형식
        
        csv_path = os.path.join(csv_dir, csv_filename)
        
        if not os.path.exists(csv_path):
            print(f"⚠️ 백업할 CSV 파일이 없습니다: {csv_path}")
            return False
        
        # 백업 파일명 생성
        if not backup_suffix:
            backup_suffix = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        backup_filename = f"klook_{city_name}_products_backup_{backup_suffix}.csv"
        backup_path = os.path.join(csv_dir, backup_filename)
        
        # 파일 복사
        import shutil
        shutil.copy2(csv_path, backup_path)
        
        print(f"✅ CSV 백업 완료: {backup_path}")
        return True
        
    except Exception as e:
        print(f"❌ CSV 백업 실패: {e}")
        return False

# =============================================================================
# 🧹 파일 시스템 정리
# =============================================================================

def cleanup_temp_files():
    """임시 파일 정리"""
    temp_patterns = [
        "*.temp",
        "*.tmp",
        "cookies/*/Default/Cookies",
        "cookies/*/Default/Cookies-journal"
    ]
    
    cleaned_count = 0
    for pattern in temp_patterns:
        try:
            import glob
            temp_files = glob.glob(pattern, recursive=True)
            for temp_file in temp_files:
                try:
                    os.remove(temp_file)
                    cleaned_count += 1
                except:
                    pass
        except:
            pass
    
    if cleaned_count > 0:
        print(f"🧹 임시 파일 {cleaned_count}개 정리 완료")
    
    return cleaned_count


print("✅ 그룹 2 완료: 이미지 처리 및 데이터 저장 함수들 정의 완료!")
print("   📸 이미지 시스템:")
print("   - get_image_src_klook(): KLOOK 이미지 URL 수집")
print("   - download_and_save_image_klook(): 이미지 다운로드 및 최적화")
print("   💾 데이터 저장:")
print("   - save_to_csv_klook(): CSV 저장 (도시국가 특별 처리)")
print("   - create_product_data_structure(): 상품 데이터 구조 생성")
print("   📊 데이터 관리:")
print("   - get_csv_stats(): CSV 통계 조회")
print("   - backup_csv_data(): 데이터 백업")
print("   🧹 시스템 관리:")
print("   - cleanup_temp_files(): 임시 파일 정리")