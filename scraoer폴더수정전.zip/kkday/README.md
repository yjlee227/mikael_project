# KKday 여행상품 크롤링 시스템

KKday 웹사이트에서 여행상품 정보를 자동으로 수집하고 분석하는 통합 시스템입니다.

## 📋 주요 기능

### 🎯 핵심 기능
- **상품 정보 자동 수집**: KKday 웹사이트에서 여행상품 데이터 크롤링
- **이미지 자동 다운로드**: 메인 이미지 및 썸네일 이미지 저장
- **데이터 정규화**: 도시명 별칭 처리 및 표준화
- **CSV 데이터 관리**: 체계적인 데이터 저장 및 중복 제거
- **위치 학습 시스템**: AI 기반 위치 키워드 자동 학습

### 🌍 지원 범위
- **전 세계 주요 도시**: 아시아, 유럽, 북미, 오세아니아 등
- **다양한 상품 카테고리**: 투어, 액티비티, 교통, 숙박 등
- **다국어 지원**: 한국어, 영어 등 다언어 데이터 처리

## 🏗️ 시스템 구조

### 📁 디렉토리 구조
```
kkday/
├── src/                           # 소스 코드
│   ├── config.py                  # 전역 설정
│   ├── scraper/                   # 크롤링 엔진
│   │   ├── crawler.py             # 메인 크롤러
│   │   ├── driver_manager.py      # 웹드라이버 관리
│   │   ├── parsers.py             # 데이터 파싱
│   │   ├── ranking.py             # 순위 시스템
│   │   └── url_manager.py         # URL 관리
│   └── utils/                     # 유틸리티
│       ├── city_manager.py        # 도시 정보 관리
│       ├── file_handler.py        # 파일 처리
│       └── location_learning.py   # 위치 학습 시스템
├── data/                          # 수집된 데이터
│   └── [대륙]/[국가]/[도시]/      # 계층적 데이터 저장
├── kkday_img/                     # 이미지 저장소
│   └── [대륙]/[국가]/[도시]/      # 이미지 파일
├── location_data/                 # 위치 학습 데이터
├── kkday_crawler.ipynb            # 메인 크롤러 노트북
├── kkday_Sitemap_Collector.ipynb # 사이트맵 수집기
├── kkday_Sitemap_Crawler.ipynb   # 사이트맵 크롤러
├── kkday_ad_link generator.ipynb # 제휴링크 생성기
└── README.md                      # 프로젝트 문서
```

### 🔧 주요 모듈

#### **config.py**
- 전역 설정 관리 (도시 정보, API 설정 등)
- 130개+ 도시 정보 데이터베이스
- 대륙/국가/도시 계층 구조

#### **scraper/ 모듈**
- **crawler.py**: 메인 크롤링 로직
- **driver_manager.py**: Selenium 웹드라이버 관리
- **parsers.py**: HTML 파싱 및 데이터 추출
- **ranking.py**: 상품 순위 시스템
- **url_manager.py**: URL 생성 및 관리

#### **utils/ 모듈**
- **city_manager.py**: 도시명 정규화 및 별칭 처리
- **file_handler.py**: CSV/이미지 파일 저장 관리
- **location_learning.py**: AI 기반 위치 키워드 학습

## 🚀 설치 및 실행

### 📋 필수 요구사항
```bash
# Python 3.8+
# Chrome 브라우저

# 필수 라이브러리
pip install selenium requests pillow beautifulsoup4 lxml
pip install undetected-chromedriver

# 선택 라이브러리 (한국어 처리)
pip install konlpy
```

### ⚙️ 환경 설정
1. Chrome 브라우저 최신버전 설치
2. 프로젝트 루트에서 필요한 디렉토리가 자동 생성됨
3. `src/config.py`에서 설정 확인

### 🎮 실행 방법

#### 1️⃣ Jupyter 노트북 (추천)
```bash
# 메인 크롤러
jupyter notebook kkday_crawler.ipynb

# 사이트맵 수집
jupyter notebook kkday_Sitemap_Collector.ipynb

# 사이트맵 크롤링  
jupyter notebook kkday_Sitemap_Crawler.ipynb

# 제휴링크 생성
jupyter notebook "kkday_ad_link generator.ipynb"
```

#### 2️⃣ Python 스크립트
```python
from src.scraper.crawler import KKdayCrawler
from src.utils.city_manager import normalize_city_name

# 크롤러 초기화
crawler = KKdayCrawler()

# 특정 도시 크롤링
city_name = "도쿄"
crawler.crawl_city(city_name, max_pages=5)
```

## 📊 데이터 출력

### 🗂️ CSV 데이터 구조
```csv
번호,상품명,가격,평점,리뷰수,URL,도시ID,도시명,대륙,국가,위치태그,카테고리,언어,투어형태,미팅방식,소요시간,하이라이트,순위,통화,수집일시,데이터소스,해시값,메인이미지,썸네일이미지
1,도쿄 디즈니랜드 입장권,65000,4.8,1234,https://...,TYO,도쿄,아시아,일본,디즈니,테마파크,한국어,개별,집합지,1일,매직킹덤,1,KRW,2024-12-07 10:30:00,KKday,abc123def456,TYO_0001.jpg,TYO_0001_thumb.jpg
```

### 🖼️ 이미지 파일
- **메인 이미지**: `{도시코드}_{번호:04d}.jpg` (예: TYO_0001.jpg)
- **썸네일**: `{도시코드}_{번호:04d}_thumb.jpg` (예: TYO_0001_thumb.jpg)
- **저장 경로**: `kkday_img/아시아/일본/도쿄/`

## 🎯 주요 특징

### ✨ 스마트 중복 제거
- MD5 해시 기반 중복 상품 자동 감지
- 번호 연속성 자동 관리

### 🌏 글로벌 도시 지원
- 130개+ 도시 정보 내장
- 도시명 별칭 자동 처리 (예: "토쿄" → "도쿄")
- 대륙별 계층 구조 자동 생성

### 🤖 AI 위치 학습
- KoNLPy 기반 한국어 자연어 처리
- 위치 키워드 자동 학습 및 태깅
- 사용자 검색 패턴 분석

### 🛡️ 안정성
- undetected-chromedriver 사용으로 차단 방지
- 예외 처리 및 재시도 로직
- 실행 환경 자동 감지

## 🔧 설정 옵션

### config.py 주요 설정
```python
CONFIG = {
    "SAVE_IMAGES": True,           # 이미지 저장 여부
    "MAX_RETRIES": 3,              # 재시도 횟수
    "WAIT_TIME": 2,                # 대기 시간(초)
    "USER_AGENT": "...",           # User-Agent 설정
}
```

### 도시 정보 추가
```python
UNIFIED_CITY_INFO = {
    "새도시": {
        "대륙": "아시아",
        "국가": "한국", 
        "코드": "NEW",
        "영문명": "New City"
    }
}
```

## 📈 성능 및 통계

- **처리 속도**: 페이지당 평균 3-5초
- **데이터 품질**: 95%+ 정확도
- **이미지 최적화**: 자동 리사이징 (메인 400px, 썸네일 200px)
- **저장 효율**: 평균 이미지 크기 < 300KB

## 🚨 주의사항

1. **합법적 사용**: 웹사이트 이용약관 준수 필수
2. **적절한 속도**: 서버 부하 방지를 위한 적절한 대기시간 설정
3. **개인정보**: 수집된 데이터의 적절한 관리 필요
4. **저작권**: 이미지 및 콘텐츠 저작권 주의

## 🔄 개발 및 수정 가이드

### 📝 코드 수정 프로세스
**중요**: 모든 코드 수정은 다음 프로세스를 따릅니다.

1. **수정 내용 미리보기**: 수정할 코드를 먼저 제시
2. **사용자 확인**: 사용자가 수정 내용 검토 및 승인
3. **직접 수정 여부**: 사용자가 직접 수정할지, 자동 수정할지 결정
4. **수정 적용**: 승인된 내용만 실제 코드에 반영

### 🛠️ 앞으로의 작업 방향성

#### **1단계: 핵심 모듈 완성 (현재 진행중)**
- ✅ `src/config.py` - 전역 설정 완료
- ✅ `src/utils/` - 유틸리티 모듈 완료
- 🔄 `src/scraper/` - 크롤링 엔진 모듈 수정 중
  - `crawler.py` - 메인 크롤링 로직
  - `driver_manager.py` - 웹드라이버 관리
  - `parsers.py` - 데이터 파싱
  - `ranking.py` - 순위 시스템
  - `url_manager.py` - URL 관리

#### **2단계: Jupyter 노트북 업데이트**
- `kkday_crawler.ipynb` - 메인 크롤러 노트북
- `kkday_Sitemap_Collector.ipynb` - 사이트맵 수집기
- `kkday_Sitemap_Crawler.ipynb` - 사이트맵 크롤러  
- `kkday_ad_link generator.ipynb` - 제휴링크 생성기

#### **3단계: 시스템 통합 및 검증**
- 전체 모듈 간 연동 테스트
- KKday 웹사이트 구조 대응 검증
- 성능 최적화 및 안정성 향상

#### **4단계: 고도화 (v2.0 계획)**
- 머신러닝 기반 상품 분류 시스템
- 실시간 가격 모니터링
- API 인터페이스 제공
- 웹 대시보드 구축

### 🔧 현재 수정 작업 상태

**완료된 작업:**
- ✅ Klook → KKday 기본 설정 변환
- ✅ 도시 관리 시스템 정리
- ✅ 파일 처리 시스템 업데이트
- ✅ 위치 학습 시스템 경로 수정

**진행 중인 작업:**
- 🔄 스크래퍼 모듈 KKday 전용 변환
- 🔄 HTML 셀렉터 KKday 구조 대응

**예정된 작업:**
- ⏳ Jupyter 노트북 코드 업데이트
- ⏳ 전체 시스템 통합 테스트
- ⏳ 성능 최적화 및 문서화

## 🔄 업데이트 내역

### v1.0 (현재 개발중)
- Klook → KKday 시스템 전환 작업
- 전 세계 주요 도시 지원 확대
- AI 기반 위치 학습 시스템 고도화
- 통합 데이터 관리 시스템 구축

### v2.0 (계획)
- 머신러닝 기반 상품 추천 시스템
- 실시간 데이터 모니터링
- RESTful API 제공
- 웹 인터페이스 제공

## 🤝 기여 방법

1. **새로운 도시 정보 추가**: `src/config.py` 수정
2. **HTML 셀렉터 업데이트**: KKday 웹사이트 변경 대응
3. **성능 최적화**: 크롤링 속도 및 메모리 사용량 개선
4. **버그 리포트**: 이슈 발생 시 상세한 오류 정보 제공
5. **기능 개선**: 새로운 기능 아이디어 및 구현

### 📋 수정 요청 시 포함할 정보
- 수정할 파일 경로
- 현재 코드와 수정 후 코드 비교
- 수정 이유 및 기대 효과
- 테스트 결과 (가능한 경우)

---

**⚠️ 면책 조항**: 이 도구는 교육 및 연구 목적으로 제작되었습니다. 상업적 이용 시 관련 법규를 확인하시기 바랍니다.

**📞 문의사항**: 시스템 사용 중 문의사항이나 개선 제안이 있으시면 언제든 연락주세요!