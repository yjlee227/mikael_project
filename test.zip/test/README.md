# 🎮 KLOOK 크롤링 시스템 사용 가이드

349KB 대용량 Jupyter 노트북을 완전히 모듈화한 KLOOK 크롤링 시스템입니다.

## 📁 프로젝트 구조

```
test/
├── klook_modules/          # 📦 메인 모듈 패키지
│   ├── config.py          # ⚙️ 설정 및 기본 상수 (그룹 1)
│   ├── data_handler.py    # 💾 데이터 처리 및 저장 (그룹 2)
│   ├── url_manager.py     # 🔗 URL 관리 및 sitemap (그룹 3)
│   ├── system_utils.py    # 🛠️ 시스템 유틸리티 (그룹 4,5)
│   ├── driver_manager.py  # 🚗 드라이버 및 브라우저 제어 (그룹 6)
│   ├── tab_selector.py    # 🎯 탭 셀렉터 시스템 (그룹 7)
│   ├── url_collection.py  # 🔍 URL 수집 및 분석 (그룹 8)
│   ├── crawler_engine.py  # 🕷️ 크롤링 엔진 (그룹 9-A,9-B)
│   ├── category_system.py # 🏷️ 카테고리 분류 (그룹 10)
│   └── control_system.py  # 🎮 전체 시스템 제어 (그룹 11,11.5)
├── run_klook_crawler.py   # 🚀 메인 실행 스크립트
├── demo.py               # 🎭 데모 및 예제
└── README.md            # 📖 이 파일
```

## 🚀 빠른 시작

### 1. 가장 간단한 방법
```bash
python demo.py
```

### 2. 명령줄에서 바로 실행
```bash
# 서울 50개 상품 (기본값)
python run_klook_crawler.py

# 부산 30개 상품
python run_klook_crawler.py --city 부산 --count 30

# 대화형 모드
python run_klook_crawler.py --interactive

# 시스템 상태만 확인
python run_klook_crawler.py --status
```

### 3. Python 코드에서 직접 사용
```python
from klook_modules import control_system

# 빠른 시작
result = control_system.quick_start_klook_crawler("서울", 50)

# 완전한 워크플로우
result = control_system.execute_complete_klook_workflow(
    city_name="부산",
    target_products=30,
    interactive_mode=False
)

# 시스템 상태 확인
status = control_system.system_status_check()
```

## 🎯 실행 모드

### 1. **빠른 시작 모드** ⚡
- 기본 설정으로 즉시 실행
- 초보자에게 추천
```python
control_system.quick_start_klook_crawler("서울", 50)
```

### 2. **대화형 모드** 🎭
- 단계별로 설정을 입력하며 실행
- 세부 설정 필요시 추천
```python
control_system.interactive_klook_crawler()
```

### 3. **완전 제어 모드** 🎮
- 모든 매개변수를 직접 제어
- 고급 사용자용
```python
control_system.execute_complete_klook_workflow(
    city_name="제주도",
    target_products=100,
    interactive_mode=True
)
```

## 🔧 시스템 요구사항

### 필수 라이브러리
```bash
pip install selenium chromedriver-autoinstaller undetected-chrome user-agents
```

### Python 버전
- Python 3.7 이상 권장

## 📊 실행 결과

시스템은 다음과 같은 결과를 생성합니다:

### 📁 생성되는 폴더
```
data/                   # 크롤링된 상품 데이터
klook_thumb_img/        # 상품 이미지
url_collected/          # 수집된 URL 목록
ranking_urls/           # 순위 정보
pagination_state/       # 페이지네이션 상태
reports/               # 분석 보고서
```

### 📋 실행 단계
1. 🚀 시스템 초기화
2. 🌍 도시 정보 설정  
3. 🧭 페이지 네비게이션
4. 🎯 탭 셀렉터
5. 🔗 URL 수집
6. 🕷️ 메인 크롤링
7. 🏷️ 카테고리 분류
8. 📊 결과 정리

## 🛠️ 고급 사용법

### 개별 모듈 사용
```python
# 특정 모듈만 사용
from klook_modules import tab_selector, url_collection

# 탭 셀렉터만 실행
result = tab_selector.execute_tab_selector_system("서울", driver)

# URL 수집만 실행
result = url_collection.run_optimized_group8()
```

### 시스템 모니터링
```python
# 상태 확인
control_system.system_status_check()

# 시스템 정리
control_system.cleanup_system()
```

## 🐞 문제 해결

### 자주 발생하는 문제

1. **크롬드라이버 오류**
   ```bash
   # 크롬 업데이트 후 재시도
   pip install --upgrade chromedriver-autoinstaller
   ```

2. **시스템 상태 확인**
   ```python
   python run_klook_crawler.py --status
   ```

3. **권한 오류**
   ```bash
   # 관리자 권한으로 실행
   sudo python run_klook_crawler.py
   ```

## 📈 성능 최적화 팁

### 1. 목표 상품 수 조정
- 테스트: 10-30개
- 일반 사용: 50-100개  
- 대량 수집: 200개 이상

### 2. 시간대별 실행
- 권장: 오전 9-11시, 오후 2-4시
- 피해야 할 시간: 점심시간, 저녁시간

### 3. 시스템 리소스
- RAM: 4GB 이상 권장
- CPU: 멀티코어 권장

## 🔗 추가 정보

- **원본 노트북**: 349KB → **모듈화된 시스템**: 10개 독립 모듈
- **호환성**: 기존 코드와 100% 호환
- **확장성**: 새로운 기능 추가 용이
- **유지보수**: 모듈별 독립 관리

## 📞 지원

문제가 발생하면 다음을 시도해보세요:

1. `python run_klook_crawler.py --status`로 시스템 상태 확인
2. `demo.py`로 기본 동작 테스트
3. 각 모듈을 개별적으로 테스트

---

🎉 **KLOOK 크롤링 시스템을 즐겁게 사용하세요!**